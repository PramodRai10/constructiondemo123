import React from "react";
import "./header.css";
import { Link } from "@reach/router";

function Header() {
  let obj = window.localStorage.getItem('user_login');
  console.log(obj)
  if (typeof (obj) == "string") {
      obj = JSON.parse(obj);
  } else {
      obj = {};
  }
  console.log(obj)
  return (
    <header>
      <div className="flex-box2">
        <div className="left-flex2">
          <Link style={{ textDecoration: "none" }} to="/"><h1 className="header-logo">Logo</h1></Link>
        </div>
        <div className="right-flex2">
            {Object.keys(obj).length != 0 && obj.constructor === Object && <Link to="/"><button className="buttonHeader" onClick={()=> window.localStorage.removeItem('user_login')}>Logout</button></Link>}
            {Object.keys(obj).length === 0 && obj.constructor === Object && <Link to="/login"><button className="buttonHeader">Login</button></Link>}
        </div>
      </div>
    </header>
  );
}

export default Header;